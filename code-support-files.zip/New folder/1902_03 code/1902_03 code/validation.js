function mycallback(v)
{
	if(v == 'valid')
	{
		return true;
	}
	else
	{
		return false;	
	}
}