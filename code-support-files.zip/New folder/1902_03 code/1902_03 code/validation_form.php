<?php

require_once($CFG->libdir.'/formslib.php');

class validation_form extends moodleform
{
	function definition()
	{
		$mform =& $this->_form;
		
		$mform->addElement('text', 'mytext1', 'My text 1');
		$mform->addRule('mytext1', 'Required', 'required', null, 'client');
		
		$mform->addElement('text', 'mytext2', 'Max length 5');
		$mform->addRule('mytext2', 'Max length 5', 'maxlength', 5, 'client');
		
		$mform->addElement('text', 'mytext3', 'Min length 5');
		$mform->addRule('mytext3', 'Min length 5', 'minlength', 5, 'client');
		
		$mform->addElement('text', 'mytext4', 'Length 3-5');
		$mform->addRule('mytext4', 'Length 3-5', 'rangelength', array(3,5), 'client');
		
		$mform->addElement('text', 'mytext5', 'URL');
		$mform->addRule('mytext5', 'URL', 'regex', '^http://^', 'server');
		
		$mform->addElement('text', 'mytext6', 'Email');
		$mform->addRule('mytext6', 'Email', 'email', null, 'client');
		
		$mform->addElement('text', 'mytext7', 'Letters only');
		$mform->addRule('mytext7', 'Letters only', 'lettersonly', null, 'client');
		
		$mform->addElement('text', 'mytext8', 'Alpha-numeric');
		$mform->addRule('mytext8', 'Alpha-numeric', 'alphanumeric', null, 'client');
		
		$mform->addElement('text', 'mytext9', 'Numeric');
		$mform->addRule('mytext9', 'Numeric', 'numeric', null, 'client');
		
		$mform->addElement('text', 'mytext10', 'No punctuation');
		$mform->addRule('mytext10', 'No punctuation', 'nopunctuation', null, 'client');
		
		$mform->addElement('text', 'mytext11', 'No leading zero');
		$mform->addRule('mytext11', 'No leading zero', 'nonzero', null, 'client');
		
		$mform->addElement('text', 'mytext12', 'Must be equal (1st)');
		$mform->addElement('text', 'mytext12_compare', 'Must be equal (2nd)');
		$mform->addRule( array('mytext12','mytext12_compare'), 'Must match', 'compare', 'eq', 'server' );
		
		$mform->addElement('text', 'mytext13', 'Custom');
		$mform->addRule('mytext13', 'Custom', 'callback', 'mycallback', 'client');
		
		
		$mform->addElement('submit', 'submitbutton', 'Submit');
		
	}
}

?>