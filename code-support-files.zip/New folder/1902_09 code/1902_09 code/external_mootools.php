<?php

require_once(dirname(__FILE__) . '/../config.php');

$PAGE->set_context(get_context_instance(CONTEXT_SYSTEM));
$PAGE->set_url('/cook/external_mootools.php');
$PAGE->requires->js('/cook/mootools-core-1.3.js');
$PAGE->requires->js('/cook/external_mootools.js');

echo $OUTPUT->header();

echo $OUTPUT->footer();

?>