<?php

require_once(dirname(__FILE__) . '/../config.php');

$PAGE->set_context(get_context_instance(CONTEXT_SYSTEM));
$PAGE->set_url('/cook/external_scriptaculous.php');
$PAGE->requires->js('/cook/prototype.js');
$PAGE->requires->js('/cook/scriptaculous/scriptaculous.js');
$PAGE->requires->js('/cook/scriptaculous/effects.js');
$PAGE->requires->js('/cook/external_scriptaculous.js');

echo $OUTPUT->header();

?>
<div id="demo">Hello from script.aculo.us</div>
<?php

echo $OUTPUT->footer();

?>