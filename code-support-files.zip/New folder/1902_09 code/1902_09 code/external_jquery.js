$(document).ready(function(){
   alert('Hello from jQuery');
 });