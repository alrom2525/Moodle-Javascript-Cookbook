<?php

require_once(dirname(__FILE__) . '/../config.php');

$PAGE->set_context(get_context_instance(CONTEXT_SYSTEM));
$PAGE->set_url('/cook/external_jquery.php');
$PAGE->requires->js('/cook/jquery-1.4.4.min.js');
$PAGE->requires->js('/cook/external_jquery.js');

echo $OUTPUT->header();

echo $OUTPUT->footer();

?>