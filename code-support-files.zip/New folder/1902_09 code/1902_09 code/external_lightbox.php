<?php

require_once(dirname(__FILE__) . '/../config.php');

$PAGE->set_context(get_context_instance(CONTEXT_SYSTEM));
$PAGE->set_url('/cook/external_lightbox.php');

$PAGE->requires->js('/cook/prototype.js');
$PAGE->requires->js('/cook/scriptaculous/scriptaculous.js');
$PAGE->requires->js('/cook/scriptaculous/effects.js');
$PAGE->requires->js('/cook/scriptaculous/builder.js');
$PAGE->requires->js('/cook/lightbox2/js/lightbox.js');

$PAGE->requires->css('/cook/lightbox2/css/lightbox.css');

echo $OUTPUT->header();

?>
<a href="flower.jpg" rel="lightbox"><img src="flower.jpg" width="150" /></a>
<?php

echo $OUTPUT->footer();

?>