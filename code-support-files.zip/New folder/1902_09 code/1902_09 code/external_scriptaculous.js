document.observe("dom:loaded", function()
{
	Effect.Shake('demo');
});
