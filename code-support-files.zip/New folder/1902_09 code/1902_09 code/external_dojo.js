dojo.addOnLoad(function()
{
	alert('Hello from dojo');
});