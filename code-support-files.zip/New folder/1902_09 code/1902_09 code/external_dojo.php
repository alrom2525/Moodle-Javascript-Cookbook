<?php

require_once(dirname(__FILE__) . '/../config.php');

$PAGE->set_context(get_context_instance(CONTEXT_SYSTEM));
$PAGE->set_url('/cook/external_dojo.php');
$PAGE->requires->js('/cook/dojo.js');
$PAGE->requires->js('/cook/external_dojo.js');

echo $OUTPUT->header();

echo $OUTPUT->footer();

?>