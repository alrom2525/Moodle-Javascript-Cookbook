document.observe("dom:loaded", function() {
	alert('Hello from Prototype');
});