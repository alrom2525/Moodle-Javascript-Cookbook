window.addEvent('domready', function() {
    alert('Hello from MooTools');
});