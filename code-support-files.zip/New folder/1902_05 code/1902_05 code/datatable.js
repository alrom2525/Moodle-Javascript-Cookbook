YUI().use("yui2-datatable", "yui2-paginator", function(Y) {
	
	var YAHOO = Y.YUI2;	
	
	var dataSource = new YAHOO.util.DataSource(YAHOO.util.Dom.get("cooktable"));
		dataSource.responseType = YAHOO.util.DataSource.TYPE_HTMLTABLE;
		
		dataSource.responseSchema = {
		    fields: [
		        { key: "chapter", parser: "number" },
		        { key: "title", parser: "string" }
		    ]
		};
		
	var columns = [
	    { 
	    	key: "chapter", 
	    	label: "Chapter No.", 
	    	formatter: "number", 
	    	sortable: true,
	    	editor: new YAHOO.widget.TextboxCellEditor({ validator: YAHOO.widget.DataTable.validateNumber } ),
	    },
	    { 
	    	key: "title", 
	    	label: "Title",
	    	formatter: "string",
	    	sortable: true,
	    	editor: new YAHOO.widget.TextboxCellEditor(),

	    }
	];
	
	var config = {
		paginator : new YAHOO.widget.Paginator({
        rowsPerPage: 5
	    }),
	};
	
	var dataTable = new YAHOO.widget.DataTable("container", columns, dataSource);
	
	
	//paged
	//var dataTable = new YAHOO.widget.DataTable("container", columns, dataSource, config);
	
	//scrolling
	//var dataTableScroll = new YAHOO.widget.ScrollingDataTable("scrollable", columns, dataSource, {   
    //	height: "150px"
	//});
	
	
	dataTable.subscribe("cellClickEvent", dataTable.onEventShowCellEditor);
	dataTableScroll.subscribe("cellClickEvent", dataTable.onEventShowCellEditor);

});