<?php
	require_once(dirname(__FILE__) . '/../config.php');
	
	$PAGE->set_context(get_context_instance(CONTEXT_SYSTEM));
	$PAGE->set_url('/cook/modal.php');
	$PAGE->requires->js('/cook/modal.js', true);
	
	echo $OUTPUT->header();
?>
<input type="button" id="show" value="Show panel" />
<div id="modalContainer">
<div id="modalPanel">
	<div class="hd">Moodle</div>
    <div class="bd">
		Moodle (abbreviation for Modular Object-Oriented 
		Dynamic Learning Environment) is a free and open-source e-learning 
		software platform, also known as a Course Management System, Learning 
		Management System, or Virtual Learning Environment (VLE). As of 
		October 2010 it had a user base of 49,952 registered and verified 
		sites, serving 37 million users in 3.7 million courses.
	</div>
    <div class="ft">[Footer]</div>
</div>
</div>
<?php
	echo $OUTPUT->footer();
?>