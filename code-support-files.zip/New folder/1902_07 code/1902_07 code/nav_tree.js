YUI().use("yui2-treeview", function(Y)
{

	var YAHOO = Y.YUI2;
	
	var treeView = new YAHOO.widget.TreeView("treeContainer");
	treeView.render();
	
});