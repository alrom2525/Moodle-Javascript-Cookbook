YUI().use("node-menunav", function(Y)
{

	Y.on("contentready", function ()
	{
		this.plug(Y.Plugin.NodeMenuNav);
 
	}, "#menu");

});