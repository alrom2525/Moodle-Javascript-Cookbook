YUI().use("tabview", function(Y)
{

	var tabView = new Y.TabView
	(
		{
			srcNode: '#tabContainer'
		}
	);
	tabView.render();

});