YUI().use("yui2-resize", function(Y) {

var YAHOO = Y.YUI2;

var resize = new YAHOO.util.Resize("content");

});