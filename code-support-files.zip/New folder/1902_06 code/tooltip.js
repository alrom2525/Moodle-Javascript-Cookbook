YUI().use("yui2-yahoo-dom-event", "yui2-animation", "yui2-container", function(Y) {

var YAHOO = Y.YUI2;

var toolTip = new YAHOO.widget.Tooltip("toolTip", {
    context: "logo"});

});