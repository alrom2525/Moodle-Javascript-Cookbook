<?php

require_once(dirname(__FILE__) . '/../config.php');

$PAGE->set_context(get_context_instance(CONTEXT_SYSTEM));
$PAGE->set_url('/cook/resize.php');
$PAGE->requires->js('/cook/resize.js', true);

?>

<?php
echo $OUTPUT->header();
?>
<div id="content" style="width:20em;padding:1em;">
<p>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam pharetra metus ut velit luctus pellentesque. Pellentesque in elit elit. Ut aliquam pellentesque massa et lacinia. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Mauris et metus a nulla porta laoreet. Nullam mollis nulla quis est aliquam imperdiet. Sed eget nisi non eros iaculis molestie.
</p>
</div>
<?php

echo $OUTPUT->footer();

?>