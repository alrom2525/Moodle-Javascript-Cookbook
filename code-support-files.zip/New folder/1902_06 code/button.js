YUI().use("yui2-button", function(Y) {

var YAHOO = Y.YUI2;

var customButton = new YAHOO.widget.Button("btnButton");

});