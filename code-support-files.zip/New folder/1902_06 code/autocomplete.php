<?php

require_once(dirname(__FILE__) . '/../config.php');

$PAGE->set_context(get_context_instance(CONTEXT_SYSTEM));
$PAGE->set_url('/cook/autocomplete.php');
$PAGE->requires->js('/cook/autocomplete.js', true);

?>

<?php
echo $OUTPUT->header();
?>
<div style="width:15em;height:10em;">
    <input id="txtInput" type="text">
    <div id="txtInput_container"></div>
</div>

<div style="width:15em;height:10em;"> 
	<input id="txtCombo" type="text" style="vertical-align:top;position:static;width:11em;"><span id="toggle"></span>
	<div id="txtCombo_container"></div>
</div>
	 
<?php

echo $OUTPUT->footer();

?>