YUI().use("node", "anim", function(Y) {

var anim = new Y.Anim({
        node: '#anim-container',
        to: {
			backgroundColor:'#2EC95D'
        }
});

	Y.on("contentready", function ()
	{
		anim.run();
	}, "#anim-container");



});