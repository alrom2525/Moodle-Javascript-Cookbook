YUI().use("anim", function(Y) {

var anim = new Y.Anim({
        node: '#anim-container'
});

	Y.on("contentready", function ()
	{
		var startX = Y.one('#anim-container').getX();
		var startY = Y.one('#anim-container').getY();

		anim.set('to',{
			curve:
			[
				[startX+40, startY-40],
				[startX+160, startY]
			]
        });
		
		anim.run();
	}, "#anim-container");



});