YUI().use('datasource-io', 'datasource-xmlschema', 'node',

function(Y) {

var uri = "../webservice/rest/server.php?wstoken=cbbf322ae646cde4aa0e72f69cafc077&wsfunction=moodle_group_get_course_groups";

var dataSource = new Y.DataSource.IO({source:uri});

dataSource.plug(Y.Plugin.DataSourceXMLSchema, {
        schema: {
            resultListLocator: "SINGLE",
            resultFields: [{key:"name", locator:"KEY[@name='name']/VALUE"}]
        }
    });
    
function loadXML(){

	dataSource.sendRequest({
		request:"courseid=2",
		cfg:{
			method:"post",
			headers: {
					'Content-Type': 'application/x-www-form-urlencoded'
				}		
			},
	    callback: {
	        success: function(e){
	        	
	        	console.log(e.response.results);
	            	            
	            var xmlData = "";
	            
	            Y.Array.each(e.response.results, function(item){xmlData += item.name + '\n'});
				document.getElementById('contents').value = xmlData;
	            
	        },
	        failure: function(e){
	            alert(e.error.message);
	        }
	    }
	});
	
}

Y.on('click', loadXML, "#go");  
 		

});