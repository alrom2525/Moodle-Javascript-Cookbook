<?php

require_once(dirname(__FILE__) . '/../config.php');

$PAGE->set_url('/cook/datasource_json.php');
$PAGE->requires->js('/cook/datasource_csv.js');


echo $OUTPUT->header();
?>

<form>
	<textarea id="contents" rows="10"></textarea>
	<br />
	<input id="go" type="button" value="Get CSV">
</form>

<?
echo $OUTPUT->footer();


?>