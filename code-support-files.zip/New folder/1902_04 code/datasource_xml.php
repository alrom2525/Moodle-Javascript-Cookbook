<?php

require_once(dirname(__FILE__) . '/../config.php');

$PAGE->set_url('/cook/datasource_xml.php');
$PAGE->requires->js('/cook/datasource_xml.js');


echo $OUTPUT->header();
?>

<form>
	<textarea id="contents" rows="10"></textarea>
	<br />
	<input id="go" type="button" value="Get XML">
</form>

<?
echo $OUTPUT->footer();


?>