<?php

require_once(dirname(__FILE__) . '/../config.php');

$PAGE->set_url('/cook/text_external.php');
$PAGE->requires->js('/cook/text_external.js');


echo $OUTPUT->header();
?>

<form>
	<textarea id="contents"></textarea>
	<br />
	<input id="go" type="button" value="Get file contents" disabled="disabled">
</form>

<?
echo $OUTPUT->footer();


?>