//create a new YUI instance with io-xdr and node
YUI().use('io-xdr', 'node',

function(Y)
{
	//create config object with relative path to the io.swf transport proxy
	var xdrConfig = {
		src:'../lib/yui/3.1.1/build/io/io.swf'
	};
	
	//apply XDR transport config
	Y.io.transport(xdrConfig);
 
 	//create config object for IO
 	var cfg = {
 	  
 	  //tell IO to use 'flash' transport method
	  xdr: { use: 'flash' },
	  
	  //register a callback for the 'success' event
	  on:
	  {
	  	success: completed
	  }
	  
	};
 
 	//define a callback function for the IO request
    function completed(id, o, args)
    {
    	//write the response  body text into a textarea for display
        var data = o.responseText;    
        Y.one('#contents').set('innerText', data);
        
    };
    
    //define a function to execute the request
    var getFile = function()
    {
    	var uri = "http://media/text.txt";    	
    	var request = Y.io(uri, cfg);
    }
    
    //define a function to enable the input button when 
    //the xdr transport is successfully initialised
    var ready = function()
    {
    	Y.one('#go').set("disabled", false);
    	Y.on('click', getFile, "#go");   		
   	}
	
	//subscribe to the xdrReady event 
	//(fires when transport is ready for use)
	Y.on('io:xdrReady', ready, Y);

}

);
