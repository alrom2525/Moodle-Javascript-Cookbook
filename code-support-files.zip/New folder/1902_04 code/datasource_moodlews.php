<?php

require_once(dirname(__FILE__) . '/../config.php');

$PAGE->set_url('/cook/datasource_moodlews.php');
$PAGE->requires->js('/cook/datasource_moodlews.js');


echo $OUTPUT->header();
?>

<form>
	<textarea id="contents" rows="10"></textarea>
	<br />
	<input id="go" type="button" value="Get Data">
</form>

<?
echo $OUTPUT->footer();


?>