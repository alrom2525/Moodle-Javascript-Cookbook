<?php

require_once(dirname(__FILE__) . '/../config.php');

$PAGE->set_url('/cook/text.php');
$PAGE->requires->js('/cook/text.js', true);


echo $OUTPUT->header();
?>

<form>
	<textarea id="contents"></textarea>
	<br />
	<input id="go" type="button" value="Get file contents">
</form>

<?
echo $OUTPUT->footer();


?>