//create a new YUI instance with io-base and node
YUI().use('io-base', 'node',

function(Y)
{
 
 	//define a callback function for the IO request
    function complete(id, o, args)
    {
    	//write the response  body text into a textarea for display
        var data = o.responseText;        
        Y.one('#contents').set('innerText', data);
        
    };
 
 	//attach the callback function to io's 'complete' event
    Y.on('io:complete', complete, Y);
    
    function getFile()
    {
   		//retrieve the desired URI 
    	var uri = "text.txt";
    	var request = Y.io(uri);
    }
    
    //attach the getFile function to the click event of our button
    Y.on('click', getFile, "#go");

}

);
