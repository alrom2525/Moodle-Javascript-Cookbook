YUI().use("event-delegate", function(Y)
{

	Y.delegate("click", function (e)
	{
		var item = this.one('a').get('text');
		alert("You clicked " + item);
 
	}, "#container", "li");

});
