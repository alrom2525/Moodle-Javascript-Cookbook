YUI().use(function(Y)
{
	alert('Hello from YUI ' + Y.version);
});
