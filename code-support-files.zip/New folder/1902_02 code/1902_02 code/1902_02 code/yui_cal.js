YUI().use("yui2-calendar", function(Y)
{	
	var YAHOO = Y.YUI2;

	var cal = new YAHOO.widget.Calendar("calContainer");
	cal.render();

});
