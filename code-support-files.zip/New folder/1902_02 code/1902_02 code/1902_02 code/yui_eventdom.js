YUI().use("node-base", function(Y)
{
	
	Y.on
	(
		"available",
		function()
		{
			printMessage("Element #container 'available'"); 
		},
		"#container"
	);
	
	Y.on
	(
		"contentready",
		function()
		{
			printMessage("Elememt #container 'contentready'"); 
		},
		"#container"
	);
	
	Y.on
	(
		"domready",
		function()
		{
			printMessage("Page 'domready'"); 	
		}
	);
	
	Y.on
	(
		"load",
		function(e)
		{ 
			printMessage("Window 'load'"); 
		},
		Y.config.win
	);

	var order = 1;
	var container = Y.one('#container');
	function printMessage(message)
	{
		container.append('<p>' + order++ + '. ' + message + '</p>'); 
	}
	
});
