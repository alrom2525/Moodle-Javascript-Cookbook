function hello(Y,message,username)
{
	alert(message + ', ' + username);
}