function lang(Y)
{
	alert(M.str.moodle.course);
}